#include "lista.h"
#include "Contact.h"

#ifdef LISTA_PROBA

int main(void)
{
	Contact Oliver;
	Lista lista(Oliver);

	return 0;
}

#endif // LISTA_PROBA
